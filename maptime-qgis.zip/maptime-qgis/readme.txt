Data downloaded from City of Cambridge Open Data.

https://data.cambridgema.gov/Traffic-Parking-and-Transportation/Cambridge-Parking-Tickets-for-the-period-January-t/vnxa-cuyr

Download date: August 15, 2014